"""
GET /v1/portal_partners/list
Validate 200 OK and collect (parse) the response body.
"""

from http import HTTPStatus
import pytest
import requests

pytestmark = [pytest.mark.get, pytest.mark.portal_partners]


def test_get_portal_partners_list(base_url, header):
    """
    Simple smoke: just check the response code and parse JSON.
    """
    url = f"{base_url}/v1/portal_partners/list"

    # Optional query params — tweak if you want pagination,
    # leaving them out is fine too.
    params = {
        "page": 1,
        "per_page": 10,
        # "sorted_by": "partner_name",
        # "sorted_order": "asc",
    }

    resp = requests.get(url, headers=header, params=params, timeout=30)
    assert resp.status_code == HTTPStatus.OK, resp.text

    # Collect/parse the response (and print so it shows in logs)
    data = resp.json()
    print("partners_list sample:", (data[:1] if isinstance(data, list) else data))
